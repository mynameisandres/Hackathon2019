//
//  UDPServer.swift
//  FinalTello
//
//  Created by Gerardo Aguilar on 1/20/19.
//  Copyright © 2019 Gerardo Aguilar. All rights reserved.
//

import Foundation
import Network
import UIKit

class UDPServer {
    var listener: NWListener
    var queue: DispatchQueue
    var connected: Bool = false
    //weak var controller: UIViewController?
    
    init?() {
        queue = DispatchQueue(label: "UDP Server Queue")
        
        //Create the listener
        listener = try! NWListener(using: .udp, on: .init(integerLiteral: 11111))
        
        listener.service = NWListener.Service(type: "_camera._udp")
        listener.serviceRegistrationUpdateHandler = { (serviceChange) in
            switch (serviceChange) {
            case .add(let endpoint):
                switch endpoint {
                case let .service(name, _, _, _):
                    print("Listening as \(name)")
//                    self.controller?.advertised(name: name)
                default:
                    break
                }
            default:
                break
            }
        }
        
        listener.newConnectionHandler = { [weak self] (newConnection) in
            if let strongSelf = self{
                newConnection.start(queue: strongSelf.queue)
                strongSelf.receive(on: newConnection)
                
            }
        }
        
        listener.stateUpdateHandler = { [ weak self] (newState) in
            switch (newState) {
            case .ready:
                print("listening on port\(String(describing: self?.listener.port))")
            case .failed(let error):
                print("Listener failed with error: \(error)")
            default:
                break
            }
        }
        
        listener.start(queue: queue)
    }
    
    func receive(on connection: NWConnection) {
        connection.receive(minimumIncompleteLength: 0, maximumLength: 1000) { (content, context, isComplete, error) in
            if let frame = content{
                if !self.connected{
                    connection.send(content: frame, completion: .idempotent)
                    print("Echoed initial content: \(frame)")
                    self.connected = true
                } else {
//                    self.controller?.received(frame: frame)
                }
                if error == nil{
                    self.receive(on: connection)
                }
            }
        }
    }
}
