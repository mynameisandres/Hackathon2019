//
//  UDPClient.swift
//  FinalTello
//
//  Created by Gerardo Aguilar on 1/19/19.
//  Copyright © 2019 Gerardo Aguilar. All rights reserved.
// UDP client connecting to the Tello Drone
//

import Foundation
import Network

class UDPClient{
    var connection: NWConnection
    var queue: DispatchQueue
    
    init(name: String){
        queue = DispatchQueue(label: "UDP Client Queue")
        
        // Create the connection
        connection = NWConnection(host: .init("192.168.10.1"), port: .init(integerLiteral: 8889), using: .udp)
        //connection = NWConnection(to: .service(name: name, type: "_camera._udp", domain: "192.168.10.1", interface: nil), using: .udp)
        
        // Set the state update handler
        connection.stateUpdateHandler = {
            [weak self] (newState) in
            switch (newState) {
            case .ready:
                print("Ready to send")
                self?.sendInitialFrame()
            case .failed(let error):
                print("Client failed with error: \(error)")
            default:
                break
            }
        }
        
        connection.start(queue: queue)
    }
    
    func sendInitialFrame() -> String{
        var response: String = ""
        let helloMessage = "command".data(using: .utf8)
        connection.send(content: helloMessage, completion: .contentProcessed({(error) in
            if let error = error{
                print("Send error: \(error)")
                response = "Failure.."
            }else{
                response = "Success!"
                print("Success!")
            }
        }))
        
        connection.receive(minimumIncompleteLength: 0, maximumLength: 100) { (content, context, isComplete, error) in
            if content != nil{
                print("Got connected!")
//                if let controller = self.controller {
//                    controller.connected()
//                }
            }
        }
        return response
    }
    
    func sendthis(command: String) -> String{
        print(command)
        var response: String = ""

        let helloMessage = command.data(using: .utf8)
        connection.send(content: helloMessage, completion: .contentProcessed({(error) in
            if let error = error{
                print("Send error: \(error)")
                response = "Failure.."
            }else{
                response = "Success!"
                print("Success!")
            }
        }))
        
        connection.receive(minimumIncompleteLength: 0, maximumLength: 100) { (content, context, isComplete, error) in
            if content != nil{
                print("Got connected!")
                //                if let controller = self.controller {
                //                    controller.connected()
                //                }
            }
        }
        
        return response

    }
    
    //Send Frames from the camera to the other device
    func send(frames: [Data]){
        connection.batch{
            for frame in frames{
                connection.send(content: frame, completion: .contentProcessed({(error) in
                    if let error = error {
                        print("Send error: \(error)")
                    }
                }))
            }
        }
    }
}
