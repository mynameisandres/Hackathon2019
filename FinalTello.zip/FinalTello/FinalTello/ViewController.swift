//
//  ViewController.swift
//  FinalTello
//
//  Created by Gerardo Aguilar on 1/19/19.
//  Copyright © 2019 Gerardo Aguilar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    var client: UDPClient = UDPClient(name: "Jerry")
    
    
    @IBOutlet weak var CommandButton: UIButton!
    @IBAction func TestButton(_ sender: UIButton) {
        var res = client.sendInitialFrame()
        if res == "Success!"{
            self.CommandButton.isHidden = true
        }
    }
    
    
    @IBAction func testTakeOff(_ sender: UIButton) {
        client.sendthis(command: "takeoff")
    }
    
    

}

